"""
GDELT BigQuery 수집기
---------------------
GCP BigQuery의 gdelt-bq 공개 데이터셋을 이용해
2014~2023년 GKG + Events 데이터를 월 단위로 수집합니다.

사전 준비:
    pip install google-cloud-bigquery pandas pyarrow tqdm
    gcloud auth application-default login
"""

import logging
import re
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd
from google.cloud import bigquery
from tqdm import tqdm

from config import (
    BQ_CONFIG, DATE_END, DATE_START, GKG_THEMES,
    CAMEO_ROOT_CODES, OUTPUT_CONFIG,
    EXCLUDE_DOMAINS, LANG_PRIMARY, LANG_SECONDARY,
)

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────
# SQL 템플릿
# ──────────────────────────────────────────────────────────────

GKG_QUERY_TEMPLATE = """
-- GDELT GKG: 경제·시장 관련 기사 수집
-- 대상 기간: {year_month_start} ~ {year_month_end}

WITH raw AS (
  SELECT
    CAST(DATE AS STRING)                          AS gkg_date_raw,
    PARSE_DATETIME('%Y%m%d%H%M%S', CAST(DATE AS STRING)) AS published_at,
    SourceCommonName                              AS source_name,
    DocumentIdentifier                            AS url,
    -- V2Themes: 세미콜론 구분 "테마,위치오프셋;테마,위치오프셋;..."
    ARRAY(
      SELECT TRIM(SPLIT(t, ',')[OFFSET(0)])
      FROM UNNEST(SPLIT(IFNULL(V2Themes, ''), ';')) AS t
      WHERE TRIM(t) != ''
    )                                             AS themes,
    -- V2Persons / V2Organizations → 엔티티
    ARRAY(
      SELECT TRIM(SPLIT(p, ',')[OFFSET(0)])
      FROM UNNEST(SPLIT(IFNULL(V2Persons, ''), ';')) AS p
      WHERE TRIM(p) != ''
    )                                             AS persons,
    ARRAY(
      SELECT TRIM(SPLIT(o, ',')[OFFSET(0)])
      FROM UNNEST(SPLIT(IFNULL(V2Organizations, ''), ';')) AS o
      WHERE TRIM(o) != ''
    )                                             AS organizations,
    -- V2Tone: "tone,postone,negtone,polarity,activity,selfrefs,wordcount"
    SPLIT(IFNULL(V2Tone, ''), ',')[SAFE_OFFSET(0)] AS tone,
    TranslationInfo,
    -- 언어 추출 (srclc:kor 또는 eng 형태)
    REGEXP_EXTRACT(TranslationInfo, r'srclc:([a-z]+)') AS lang_code,
  FROM `{gkg_table}`
  WHERE
    -- 기간 필터 (INTEGER DATE 형식)
    DATE >= {date_start_int}
    AND DATE < {date_end_int}
    -- 언어 필터: 한국어 우선, 영어 보완
    AND (
      REGEXP_EXTRACT(TranslationInfo, r'srclc:([a-z]+)') IN ('kor', 'eng')
      OR TranslationInfo IS NULL  -- 기본 영어 기사
    )
),

-- 테마 필터: 관련 GKG 테마 중 하나라도 포함된 기사
theme_filtered AS (
  SELECT *
  FROM raw
  WHERE EXISTS (
    SELECT 1 FROM UNNEST(themes) AS t
    WHERE t IN ({theme_list})
  )
),

-- 도메인 추출 및 저품질 도메인 제외
domain_filtered AS (
  SELECT
    *,
    REGEXP_EXTRACT(url, r'https?://(?:www\.)?([^/]+)') AS domain,
  FROM theme_filtered
  WHERE
    url IS NOT NULL
    AND url != ''
    AND NOT REGEXP_CONTAINS(
      url, r'(blogspot\.com|wordpress\.com|me2\.do|naver\.me|\.ad\.|/ad/)'
    )
)

SELECT
  -- 기준 일자 (YYYYMMDD)
  SUBSTR(gkg_date_raw, 1, 8)                       AS ref_date,
  published_at,
  lang_code,
  source_name,
  domain,
  url,
  -- 테마·엔티티를 JSON 문자열로 직렬화 (BQ → Pandas 호환)
  TO_JSON_STRING(themes)                            AS themes_json,
  TO_JSON_STRING(persons)                           AS persons_json,
  TO_JSON_STRING(organizations)                     AS orgs_json,
  CAST(tone AS FLOAT64)                             AS tone_score,
FROM domain_filtered
ORDER BY published_at
"""

EVENTS_QUERY_TEMPLATE = """
-- GDELT Events: 경제·외교·제재 관련 이벤트 수집
-- 대상 기간: {year_month_start} ~ {year_month_end}

SELECT
  GlobalEventID                   AS event_id,
  CAST(Day AS STRING)             AS event_date,
  Actor1Name                      AS actor1_name,
  Actor1CountryCode               AS actor1_country,
  Actor1Type1Code                 AS actor1_type,
  Actor2Name                      AS actor2_name,
  Actor2CountryCode               AS actor2_country,
  EventCode                       AS cameo_code,
  EventBaseCode                   AS cameo_base,
  EventRootCode                   AS cameo_root,
  GoldsteinScale                  AS goldstein_scale,
  NumMentions                     AS num_mentions,
  NumSources                      AS num_sources,
  NumArticles                     AS num_articles,
  AvgTone                         AS avg_tone,
  SOURCEURL                       AS source_url,
  Actor1Geo_CountryCode           AS actor1_geo_country,
  Actor2Geo_CountryCode           AS actor2_geo_country,
  ActionGeo_CountryCode           AS action_geo_country,
FROM `{events_table}`
WHERE
  Day >= {date_start_int}
  AND Day < {date_end_int}
  -- 경제·제재·외교 관련 CAMEO 루트 코드만 수집
  AND EventRootCode IN ({cameo_list})
  -- 다중 기사로 보도된 이벤트만 (노이즈 제거)
  AND NumArticles >= 3
ORDER BY Day, GlobalEventID
"""


# ──────────────────────────────────────────────────────────────
# 유틸리티
# ──────────────────────────────────────────────────────────────

def _month_ranges(start: date, end: date):
    """start~end 사이의 월 단위 (first, last) 튜플 리스트 반환."""
    result = []
    cur = start.replace(day=1)
    while cur <= end:
        # 해당 월의 마지막 날
        if cur.month == 12:
            nxt = cur.replace(year=cur.year + 1, month=1)
        else:
            nxt = cur.replace(month=cur.month + 1)
        last = nxt - timedelta(days=1)
        result.append((cur, min(last, end)))
        cur = nxt
    return result


def _date_to_int(d: date) -> int:
    """date → GDELT DATE 정수 형식 (YYYYMMDD0000SS → 실제론 YYYYMMDD00으로 처리)."""
    return int(d.strftime("%Y%m%d") + "000000")


def _theme_list_sql(themes: list[str]) -> str:
    return ", ".join(f"'{t}'" for t in themes)


def _cameo_list_sql(codes: list[str]) -> str:
    return ", ".join(f"'{c}'" for c in codes)


# ──────────────────────────────────────────────────────────────
# 수집기
# ──────────────────────────────────────────────────────────────

class GDELTBigQueryCollector:
    """BigQuery를 통한 GDELT 대용량 수집기."""

    def __init__(self, project_id: Optional[str] = None):
        self.project_id = project_id or BQ_CONFIG["project_id"]
        self.client = bigquery.Client(project=self.project_id)
        self.output_dir = Path(OUTPUT_CONFIG["output_dir"])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        logger.info("BigQuery 클라이언트 초기화 완료 (project=%s)", self.project_id)

    # ── GKG 수집 ──────────────────────────────────────────────

    def collect_gkg(
        self,
        start: date = DATE_START,
        end: date = DATE_END,
        skip_existing: bool = True,
    ) -> None:
        """GKG 데이터를 월 단위 parquet 파일로 수집."""
        months = _month_ranges(start, end)
        logger.info("GKG 수집 시작: %s ~ %s (%d개월)", start, end, len(months))

        for month_start, month_end in tqdm(months, desc="GKG 월별 수집"):
            ym = month_start.strftime("%Y%m")
            out_path = self.output_dir / f"gkg_{ym}.parquet"

            if skip_existing and out_path.exists():
                logger.debug("스킵 (기존 파일): %s", out_path)
                continue

            sql = GKG_QUERY_TEMPLATE.format(
                year_month_start=month_start.strftime("%Y-%m-%d"),
                year_month_end=month_end.strftime("%Y-%m-%d"),
                gkg_table=BQ_CONFIG["gkg_table"],
                date_start_int=_date_to_int(month_start),
                date_end_int=_date_to_int(month_end + timedelta(days=1)),
                theme_list=_theme_list_sql(GKG_THEMES),
            )

            try:
                df = self._run_query(sql, job_label=f"gkg_{ym}")
                if df.empty:
                    logger.warning("[%s] 결과 없음", ym)
                    continue
                df.to_parquet(out_path, index=False, engine="pyarrow")
                logger.info("[%s] %d건 저장 → %s", ym, len(df), out_path)
            except Exception as exc:
                logger.error("[%s] GKG 수집 실패: %s", ym, exc)

    # ── Events 수집 ────────────────────────────────────────────

    def collect_events(
        self,
        start: date = DATE_START,
        end: date = DATE_END,
        skip_existing: bool = True,
    ) -> None:
        """GDELT Events를 월 단위 parquet 파일로 수집."""
        months = _month_ranges(start, end)
        logger.info("Events 수집 시작: %s ~ %s", start, end)

        for month_start, month_end in tqdm(months, desc="Events 월별 수집"):
            ym = month_start.strftime("%Y%m")
            out_path = self.output_dir / f"events_{ym}.parquet"

            if skip_existing and out_path.exists():
                continue

            sql = EVENTS_QUERY_TEMPLATE.format(
                year_month_start=month_start.strftime("%Y-%m-%d"),
                year_month_end=month_end.strftime("%Y-%m-%d"),
                events_table=BQ_CONFIG["events_table"],
                date_start_int=int(month_start.strftime("%Y%m%d")),
                date_end_int=int((month_end + timedelta(days=1)).strftime("%Y%m%d")),
                cameo_list=_cameo_list_sql(CAMEO_ROOT_CODES),
            )

            try:
                df = self._run_query(sql, job_label=f"events_{ym}")
                if df.empty:
                    continue
                df.to_parquet(out_path, index=False, engine="pyarrow")
                logger.info("[%s] %d건 저장 → %s", ym, len(df), out_path)
            except Exception as exc:
                logger.error("[%s] Events 수집 실패: %s", ym, exc)

    # ── GKG + Events 조인 ──────────────────────────────────────

    def join_gkg_events(self, year_month: str) -> pd.DataFrame:
        """
        동일 월의 GKG + Events 파일을 URL 기준으로 조인.
        events 정보(goldstein, tone, CAMEO)를 GKG 기사에 부착.
        """
        gkg_path = self.output_dir / f"gkg_{year_month}.parquet"
        evt_path = self.output_dir / f"events_{year_month}.parquet"

        if not gkg_path.exists():
            raise FileNotFoundError(f"GKG 파일 없음: {gkg_path}")

        gkg = pd.read_parquet(gkg_path)

        if evt_path.exists():
            events = pd.read_parquet(evt_path)
            # source_url 정규화 후 조인
            events["url_norm"] = events["source_url"].apply(_normalize_url)
            gkg["url_norm"] = gkg["url"].apply(_normalize_url)

            events_agg = (
                events.groupby("url_norm")
                .agg(
                    event_ids=("event_id", list),
                    cameo_codes=("cameo_code", list),
                    avg_goldstein=("goldstein_scale", "mean"),
                    max_mentions=("num_mentions", "max"),
                )
                .reset_index()
            )
            gkg = gkg.merge(events_agg, on="url_norm", how="left")
        else:
            gkg["event_ids"] = None
            gkg["cameo_codes"] = None
            gkg["avg_goldstein"] = None
            gkg["max_mentions"] = None

        return gkg.drop(columns=["url_norm"], errors="ignore")

    # ── 내부 헬퍼 ─────────────────────────────────────────────

    def _run_query(self, sql: str, job_label: str = "") -> pd.DataFrame:
        job_config = bigquery.QueryJobConfig(
            labels={"job": job_label[:63].replace(" ", "_").lower()},
            use_query_cache=True,
        )
        job = self.client.query(sql, job_config=job_config)
        return job.to_dataframe(progress_bar_type=None)


def _normalize_url(url: str) -> str:
    """URL 비교용 정규화 (스킴·www·트레일링 슬래시·쿼리 제거)."""
    if not isinstance(url, str):
        return ""
    url = url.lower().strip()
    url = re.sub(r"^https?://", "", url)
    url = re.sub(r"^www\.", "", url)
    url = url.rstrip("/")
    url = re.sub(r"\?.*$", "", url)
    return url
