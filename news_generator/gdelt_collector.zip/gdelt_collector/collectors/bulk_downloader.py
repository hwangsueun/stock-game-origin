"""
GDELT GKG 직접 다운로드 수집기
-------------------------------
GDELT 서버에서 15분 단위 GKG v2 파일을 직접 다운로드·파싱합니다.
BigQuery 접근이 어려울 때 사용하는 대안 방법입니다.

주의: 2014~2023년 전체는 약 350,000개 파일 → 최소 수TB 처리량 필요
      연도/월 범위를 좁혀 사용하거나, 클라우드 VM에서 실행 권장.

GKG v2 파일 형식: tab-delimited, 27개 컬럼
마스터 파일 목록: http://data.gdeltproject.org/gdeltv2/masterfilelist.txt
"""

import csv
import gzip
import io
import logging
import re
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Generator, Optional
from urllib.request import urlopen

import pandas as pd
from tqdm import tqdm

from config import (
    GKG_THEMES, DATE_START, DATE_END,
    OUTPUT_CONFIG, EXCLUDE_DOMAINS,
)

logger = logging.getLogger(__name__)

GDELT_BASE = "http://data.gdeltproject.org/gdeltv2"
MASTER_FILE_URL = f"{GDELT_BASE}/masterfilelist.txt"

# ──────────────────────────────────────────────────────────────
# GKG v2 컬럼 정의
# ──────────────────────────────────────────────────────────────
GKG_COLUMNS = [
    "GKGRECORDID", "DATE", "SourceCollectionIdentifier",
    "SourceCommonName", "DocumentIdentifier",
    "Counts", "V2Counts", "Themes", "V2Themes",
    "Locations", "V2Locations", "Persons", "V2Persons",
    "Organizations", "V2Organizations", "V2Tone",
    "Dates", "GCAM", "SharingImage", "RelatedImages",
    "SocialImageEmbeds", "SocialVideoEmbeds", "Quotations",
    "AllNames", "Amounts", "TranslationInfo", "Extras",
]

# 실제로 사용할 컬럼만 선택 (메모리 절약)
KEEP_COLUMNS = [
    "DATE", "SourceCommonName", "DocumentIdentifier",
    "V2Themes", "V2Persons", "V2Organizations", "V2Tone",
    "TranslationInfo",
]
KEEP_INDICES = [GKG_COLUMNS.index(c) for c in KEEP_COLUMNS]


# ──────────────────────────────────────────────────────────────
# 마스터 파일 목록 파싱
# ──────────────────────────────────────────────────────────────

def fetch_master_file_list(
    start: date = DATE_START,
    end: date = DATE_END,
) -> list[dict]:
    """
    GDELT 마스터 파일 목록에서 GKG 파일 URL을 추출.
    반환: [{"datetime": datetime, "size_bytes": int, "url": str}, ...]
    """
    logger.info("마스터 파일 목록 다운로드 중...")
    with urlopen(MASTER_FILE_URL, timeout=120) as resp:
        lines = resp.read().decode("utf-8").splitlines()

    entries = []
    start_dt = datetime.combine(start, datetime.min.time())
    end_dt   = datetime.combine(end, datetime.max.time())

    for line in lines:
        parts = line.strip().split()
        if len(parts) < 3:
            continue
        size_str, hash_str, url = parts[0], parts[1], parts[2]

        # GKG 파일만
        if "gkg.csv.zip" not in url and "gkg.csv.gz" not in url:
            continue

        # URL에서 타임스탬프 파싱: .../20140101120000.gkg.csv.zip
        m = re.search(r"/(\d{14})\.gkg", url)
        if not m:
            continue

        try:
            dt = datetime.strptime(m.group(1), "%Y%m%d%H%M%S")
        except ValueError:
            continue

        if start_dt <= dt <= end_dt:
            entries.append({
                "datetime": dt,
                "size_bytes": int(size_str),
                "url": url,
            })

    entries.sort(key=lambda x: x["datetime"])
    logger.info("대상 파일 수: %d개 (%s ~ %s)", len(entries), start, end)
    return entries


# ──────────────────────────────────────────────────────────────
# 단일 파일 파싱
# ──────────────────────────────────────────────────────────────

def _extract_lang_code(trans_info: str) -> str:
    if not trans_info:
        return "eng"
    m = re.search(r"srclc:([a-z]+)", trans_info)
    return m.group(1) if m else "eng"


def _has_target_theme(v2themes: str) -> bool:
    if not v2themes:
        return False
    themes_in_row = {
        t.split(",")[0].strip()
        for t in v2themes.split(";")
        if t.strip()
    }
    return bool(themes_in_row & set(GKG_THEMES))


def _parse_gkg_file(raw_bytes: bytes) -> pd.DataFrame:
    """GKG zip/gz 바이트 → 필터링된 DataFrame 반환."""
    try:
        with gzip.open(io.BytesIO(raw_bytes)) as gz:
            content = gz.read().decode("utf-8", errors="replace")
    except Exception:
        content = raw_bytes.decode("utf-8", errors="replace")

    rows = []
    reader = csv.reader(io.StringIO(content), delimiter="\t")

    for raw_row in reader:
        if len(raw_row) < max(KEEP_INDICES) + 1:
            continue

        row = {col: raw_row[idx] for col, idx in zip(KEEP_COLUMNS, KEEP_INDICES)}

        # 언어 필터
        lang = _extract_lang_code(row.get("TranslationInfo", ""))
        if lang not in ("kor", "eng"):
            continue

        # 테마 필터
        if not _has_target_theme(row.get("V2Themes", "")):
            continue

        # URL 필터
        url = row.get("DocumentIdentifier", "")
        if not url or any(excl in url for excl in EXCLUDE_DOMAINS):
            continue

        # tone 파싱 (첫 번째 값만)
        tone_raw = row.get("V2Tone", "").split(",")
        try:
            tone = float(tone_raw[0])
        except (ValueError, IndexError):
            tone = None

        # 정규화
        rows.append({
            "ref_date":     row["DATE"][:8],
            "published_at": row["DATE"],
            "source_name":  row.get("SourceCommonName", ""),
            "url":          url,
            "lang_code":    lang,
            "themes_raw":   row.get("V2Themes", ""),
            "persons_raw":  row.get("V2Persons", ""),
            "orgs_raw":     row.get("V2Organizations", ""),
            "tone_score":   tone,
        })

    return pd.DataFrame(rows)


# ──────────────────────────────────────────────────────────────
# 수집기
# ──────────────────────────────────────────────────────────────

class GDELTBulkDownloader:
    """GDELT GKG 파일 직접 다운로드 수집기."""

    DOWNLOAD_DELAY_SEC = 0.5   # 서버 부하 방지
    RETRY_COUNT        = 3

    def __init__(self):
        self.output_dir = Path(OUTPUT_CONFIG["output_dir"]) / "bulk"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def collect(
        self,
        start: date = DATE_START,
        end: date = DATE_END,
        save_every_n_files: int = 96,   # 96 * 15분 = 1일치마다 저장
    ) -> None:
        """
        지정 기간 GKG 파일을 다운로드·파싱·저장.
        save_every_n_files: 이 개수마다 중간 parquet 저장 (메모리 관리)
        """
        file_list = fetch_master_file_list(start, end)
        if not file_list:
            logger.warning("수집 대상 파일 없음")
            return

        accumulated: list[pd.DataFrame] = []
        batch_label = file_list[0]["datetime"].strftime("%Y%m%d")

        for i, entry in enumerate(tqdm(file_list, desc="GKG 파일 다운로드")):
            df_chunk = self._download_and_parse(entry["url"])
            if df_chunk is not None and not df_chunk.empty:
                accumulated.append(df_chunk)

            # N개마다 또는 마지막에 플러시
            is_last = (i == len(file_list) - 1)
            if (i + 1) % save_every_n_files == 0 or is_last:
                if accumulated:
                    self._flush(accumulated, batch_label)
                    accumulated = []
                if not is_last:
                    batch_label = entry["datetime"].strftime("%Y%m%d")

            time.sleep(self.DOWNLOAD_DELAY_SEC)

    def _download_and_parse(self, url: str) -> Optional[pd.DataFrame]:
        for attempt in range(self.RETRY_COUNT):
            try:
                with urlopen(url, timeout=60) as resp:
                    raw = resp.read()
                return _parse_gkg_file(raw)
            except Exception as e:
                if attempt < self.RETRY_COUNT - 1:
                    time.sleep(2 ** attempt)
                else:
                    logger.warning("다운로드 실패 (포기): %s — %s", url, e)
        return None

    def _flush(self, frames: list[pd.DataFrame], label: str) -> None:
        combined = pd.concat(frames, ignore_index=True)
        out_path = self.output_dir / f"gkg_bulk_{label}.parquet"
        combined.to_parquet(out_path, index=False, engine="pyarrow")
        logger.info("중간 저장: %d건 → %s", len(combined), out_path)
